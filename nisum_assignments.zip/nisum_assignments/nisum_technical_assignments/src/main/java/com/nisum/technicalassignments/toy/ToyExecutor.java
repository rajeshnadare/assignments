package com.nisum.technicalassignments.toy;

import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

import com.nisum.technicalassignments.toy.data.Quotes;
import com.nisum.technicalassignments.toy.data.Toy;
import com.nisum.technicalassignments.toy.service.ToysService;

/**
 * Executor class invokes ToyService class methods to get highest selling toy report.
 *  
 * @author nadarer
 *
 */
public class ToyExecutor {

	/**
	 * Main method to start program execution.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		
		List<Toy> toysList = new ArrayList<>(Arrays.asList(new Toy("car", 0), new Toy("plane", 0), new Toy("motor", 0), new Toy("batman", 0), new Toy("superman", 0)));
		List<Quotes> quotesList = new ArrayList<>(Arrays.asList(new Quotes("Car is a cool toy"), new Quotes("motor is good"), new Quotes("batman is cool"), new Quotes("superman is powerful"), new Quotes("superman is not human"), new Quotes("superman is most sold toy")));
		try(Scanner inputScanner = new Scanner(new InputStreamReader(System.in));) {
			System.out.println("Please Enter The number of top selling toys to be fetched.");
			String inputTopToys = inputScanner.nextLine();
			Integer topToys = Integer.parseInt(inputTopToys.trim());
			
			ToysService toysService = new ToysService();
			List<String> topSellingToysList = toysService.findHighestSellingToy(toysList, quotesList, topToys);
			
			if(null == topSellingToysList || topSellingToysList.isEmpty()) {
				System.out.println("No top selling toys found based on given input criteria.");
			} else {
				System.out.println("Top " + topToys + " selling toys are as follows.");
				for(String toyName : topSellingToysList) {
					System.out.println((null != toyName) ? toyName : "");
				}
			}
		}
		
	}

}

/*
 * Example Input and Output
 * 
 * TEST CASE # 1
 * 
 * --------------------INPUT-----------------------------------------
 * Please Enter The number of top selling toys to be fetched.
 * 1
 * --------------------INPUT-----------------------------------------
 * 
 * --------------------OUTPUT----------------------------------------
 * Top 1 selling toys are as follows.
 * superman
 * --------------------OUTPUT----------------------------------------
 * 
 * 
 * TEST CASE # 2
 * 
 * --------------------INPUT----------------------------------------- 
 * Please Enter The number of top selling toys to be fetched.
 * 3
 * --------------------INPUT-----------------------------------------
 * 
 * --------------------OUTPUT----------------------------------------
 * Top 3 selling toys are as follows.
 * superman
 * motor
 * batman
 * --------------------OUTPUT----------------------------------------
 */
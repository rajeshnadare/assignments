package com.nisum.technicalassignments.stockmarket;

import java.io.InputStreamReader;
import java.util.List;
import java.util.Scanner;

import com.nisum.technicalassignments.stockmarket.service.StockMarketService;
import static com.nisum.technicalassignments.stockmarket.util.StockMarcketUtil.SYMBOL_COMMA;

/**
 * Executor class invokes StockMarketService class methods to get stock analysis reports.
 *  
 * @author nadarer
 *
 */
public class StockMarketExecutor {

	/**
	 * Main method to start program execution.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		
		try(Scanner inputScanner = new Scanner(new InputStreamReader(System.in));) {
			System.out.println("Please Enter daywise stock price to do the profit analysis.");
			String inputStockPrices = inputScanner.nextLine();
			String[] strStockPricesArray = inputStockPrices.split(SYMBOL_COMMA);
			int[] stockPricesArray = new int[strStockPricesArray.length];
			
			for(int index = 0 ; index < strStockPricesArray.length ; index++) {
				stockPricesArray[index] = Integer.parseInt(strStockPricesArray[index].trim());
			}
			
			StockMarketService stockMarketService = new StockMarketService();
			List<String> analysedStockTradingDaysList = stockMarketService.performProfitAnalysis(stockPricesArray);
			
			if(null == analysedStockTradingDaysList || analysedStockTradingDaysList.isEmpty()) {
				System.out.println("No profit can be earned with the given stock data.");
			} else {
				System.out.println("Following are the profit scenarios with given stock data.");
				for(String stockDays : analysedStockTradingDaysList) {
					String[] stockDaysArray = (null != stockDays) ? stockDays.split(SYMBOL_COMMA) : new String[0];
					if(stockDaysArray.length > 1) {
						System.out.println("Maximum profit can be earned by buying on day " + stockDaysArray[0] + ", selling on day " + stockDaysArray[1]);
					}
				}
			}
		}
		
	}

}

/*
 * Example Input and Output
 * 
 * TEST CASE # 1
 * 
 * --------------------INPUT-----------------------------------------
 * Please Enter daywise stock price to do the profit analysis.
 * 200, 100
 * --------------------INPUT-----------------------------------------
 * 
 * --------------------OUTPUT----------------------------------------
 * No profit can be earned with the given stock data.
 * --------------------OUTPUT----------------------------------------
 * 
 * 
 * TEST CASE # 2
 * 
 * --------------------INPUT----------------------------------------- 
 * Please Enter daywise stock price to do the profit analysis.
 * 100, 180, 260, 310, 40, 535, 695
 * --------------------INPUT-----------------------------------------
 * 
 * --------------------OUTPUT----------------------------------------
 * Following are the profit scenarios with given stock data.
 * Maximum profit can be earned by buying on day 0, selling on day 3
 * Maximum profit can be earned by buying on day 4, selling on day 6
 * --------------------OUTPUT----------------------------------------
 */
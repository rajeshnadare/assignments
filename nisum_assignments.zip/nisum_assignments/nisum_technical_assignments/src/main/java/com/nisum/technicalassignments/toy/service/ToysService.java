package com.nisum.technicalassignments.toy.service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.nisum.technicalassignments.toy.data.Quotes;
import com.nisum.technicalassignments.toy.data.Toy;

/**
 * Service class which performs various operations on toy data.
 * @author nadarer
 *
 */
public class ToysService {

		/**
		 * Method to find the highest selling toys.
		 * 
		 * @param toys
		 * @param quotes
		 * @param topToys
		 * @return topSellingToysList
		 */
		public List<String> findHighestSellingToy(List<Toy> toys, List<Quotes> quotes, Integer topToys) {
			List<String> topSellingToysList = new ArrayList<> (topToys);
			int toyCounterInQuotes = 0;
			
			for(Toy toy : toys) {
				for(Quotes quote : quotes) {
					if(quote.getQuote().contains(toy.getToyName())) {
						toyCounterInQuotes++;
					}
				}
				toy.setToyCountInQuotes(toyCounterInQuotes);
				toyCounterInQuotes = 0;
			}
			
			Collections.sort(toys);
			
			for(int index = 0 ; index < topToys ; index++) {
				topSellingToysList.add(index, toys.get(index).getToyName());
			}
			
			return topSellingToysList;
		}

}

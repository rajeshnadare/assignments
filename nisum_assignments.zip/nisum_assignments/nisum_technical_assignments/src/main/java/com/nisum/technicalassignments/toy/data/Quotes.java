package com.nisum.technicalassignments.toy.data;

/**
 * Data class for Quote Entity
 * @author nadarer
 *
 */
public class Quotes {

	public Quotes(String quote) {
		super();
		this.quote = quote;
	}
	private String quote;

	public String getQuote() {
		return quote;
	}

	public void setQuote(String quote) {
		this.quote = quote;
	}
}

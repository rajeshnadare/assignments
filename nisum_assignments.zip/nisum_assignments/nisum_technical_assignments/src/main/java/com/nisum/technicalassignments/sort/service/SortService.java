package com.nisum.technicalassignments.sort.service;

import java.util.Arrays;

/**
 * Service class which performs various sorting activities.
 * @author nadarer
 *
 */
public class SortService {

		/**
		 * Method to sort int array with Insertion sort algorithm.
		 * @param numbers
		 */
		public void sortElementsUsingInsertionSort(int[] numbers) {
			int arrayLength = numbers.length;
			int selectedIndexPosition = 0;
			int selectedIndexContent = 0;
			int indexPositionToShift = 0;
			
			for(int index = 0 ; index < arrayLength ; index++) {
				
				if(index == 0) {
					selectedIndexPosition = index + 1;
				} else {
					selectedIndexPosition += 1;
				}
				
				if(selectedIndexPosition < arrayLength) {
					selectedIndexContent = numbers[selectedIndexPosition];
					for(int incrementalIndex = 0 ; incrementalIndex < selectedIndexPosition ; incrementalIndex++) {
						if(numbers[incrementalIndex] > selectedIndexContent) {
							
							indexPositionToShift = incrementalIndex;
							int[] copyOfNumbers = Arrays.copyOf(numbers, arrayLength);
							for(int sourceArrayIndex = 0, destinationArrayIndex = 0 ; sourceArrayIndex < arrayLength && destinationArrayIndex < arrayLength ; sourceArrayIndex++, destinationArrayIndex++) {
								
								if(indexPositionToShift == destinationArrayIndex) {
									numbers[destinationArrayIndex] = selectedIndexContent;
									sourceArrayIndex--;
								} else if(selectedIndexPosition == sourceArrayIndex) {
									sourceArrayIndex++;
								} else {
									numbers[destinationArrayIndex] = copyOfNumbers[sourceArrayIndex];
								}
								
							}
							break;
						}
					}
				} else {
					break;
				}
			}
		}

}

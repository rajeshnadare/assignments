package com.nisum.technicalassignments.stockmarket.util;

/**
 * Utility class to hold common Constants and methods.
 * @author nadarer
 *
 */
public class StockMarcketUtil {
	// Comma symbol required for tokenisation in general.
	public static final String SYMBOL_COMMA = ",";
}

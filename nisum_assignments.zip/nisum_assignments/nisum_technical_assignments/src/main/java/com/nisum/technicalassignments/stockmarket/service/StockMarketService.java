package com.nisum.technicalassignments.stockmarket.service;

import java.util.ArrayList;
import java.util.List;
import static com.nisum.technicalassignments.stockmarket.util.StockMarcketUtil.SYMBOL_COMMA;

/**
 * Service class which performs various operations on stocks data.
 * @author nadarer
 *
 */
public class StockMarketService {

	/**
	 * Method to do the profit analysis.
	 * @param stockPricesArray
	 * @return analysedStockTradingDaysList
	 */
	public List<String> performProfitAnalysis(int[] stockPricesArray) {
		List<String> analysedStockTradingDaysList = new ArrayList<>();
		String commaSeparatedDaysIndex = null;
		int index = 0;
		int arrayLength = stockPricesArray.length;
		
		if(noProfitStocks(stockPricesArray, arrayLength)) {
			return analysedStockTradingDaysList;
		}
		
		for( ; index < arrayLength ; index++) {
			
			if((index + 1) < arrayLength && stockPricesArray[index] < stockPricesArray[index + 1]) {
				
				commaSeparatedDaysIndex = String.valueOf(index);
				
				for(int ascendingIndex = index + 1 ; ascendingIndex < arrayLength ; ascendingIndex++) {
					
					if((ascendingIndex + 1) >= arrayLength || stockPricesArray[ascendingIndex] > stockPricesArray[ascendingIndex + 1]) {
						commaSeparatedDaysIndex = commaSeparatedDaysIndex + SYMBOL_COMMA + String.valueOf(ascendingIndex);
						analysedStockTradingDaysList.add(commaSeparatedDaysIndex);
						index = ascendingIndex;
						break;
					}
					
				}
				
			}
		}
		
		return analysedStockTradingDaysList;
	}

	/**
	 * Method to check whether it's a non-profit stock OR not.
	 * @param stockPricesArray
	 * @return noProfitStocks
	 */
	private boolean noProfitStocks(int[] stockPricesArray, int arrayLength) {
		boolean noProfitStocks = true;
	
		for(int index = 0 ; index < arrayLength ; index++) {
			for(int nextIndex = index + 1 ; nextIndex < arrayLength ; nextIndex++) {
				if(stockPricesArray[index] < stockPricesArray[nextIndex]) {
					noProfitStocks = false;
				}
			}
		}
		
		return noProfitStocks;
	}

}

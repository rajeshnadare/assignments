package com.nisum.technicalassignments.sort;

import com.nisum.technicalassignments.sort.service.SortService;

/**
 * Executor class invokes SortService class methods to get integer array sorted using Insertion Sort Algorithm.
 *  
 * @author nadarer
 *
 */
public class SortExecutor {

	/**
	 * Main method to start program execution.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		
		int[] numbers = new int[]{201, 35, -15, 7, 55, 1, -22};		
		SortService sortService = new SortService();
		sortService.sortElementsUsingInsertionSort(numbers);
		System.out.println("intArray sorted with Insetion Sort Algorithm is as follows.");
		for(int number : numbers) {
			System.out.println(number);
		}
			
	}

}

/*
 * Example Input and Output
 * 
 * TEST CASE # 1
 * 
 * --------------------INPUT-----------------------------------------
 * {201, 35, -15, 7, 55, 1, -22}
 * --------------------INPUT-----------------------------------------
 * 
 * --------------------OUTPUT----------------------------------------
 * intArray sorted with Insetion Sort Algorithm is as follows.
 * -22
 * -15
 * 1
 * 7
 * 35
 * 55
 * 201
 * --------------------OUTPUT----------------------------------------
 * 
 */
package com.nisum.technicalassignments.toy.data;

/**
 * Data class for Toy Entity
 * @author nadarer
 *
 */
public class Toy implements Comparable<Toy>{

	private String toyName;
	private int toyCountInQuotes;
	
	public Toy(String toyName, int toyCountInQuotes) {
		super();
		this.toyName = toyName;
		this.toyCountInQuotes = toyCountInQuotes;
	}
	public String getToyName() {
		return toyName;
	}
	public void setToyName(String toyName) {
		this.toyName = toyName;
	}
	public int getToyCountInQuotes() {
		return toyCountInQuotes;
	}
	public void setToyCountInQuotes(int toyCountInQuotes) {
		this.toyCountInQuotes = toyCountInQuotes;
	}
	
	@Override
	public int compareTo(Toy toy) {
		if(this.toyCountInQuotes < toy.toyCountInQuotes) {
			return 1;
		} else if (this.toyCountInQuotes > toy.toyCountInQuotes) {
			return -1;
		} else {
			return 0;
		}
	}
	
	
}
